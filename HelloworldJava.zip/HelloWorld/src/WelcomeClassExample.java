
public class WelcomeClassExample {

	public static void main(String[] args) {
		System.out.println("Hello World! My name is Dominick Simonise ");
	}

}
